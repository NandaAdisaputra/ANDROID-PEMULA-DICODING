package com.nandaadisaputra.master.buah

data class Item(val name: String?, val image: Int?)