ClubFootballApp-submission1__Kelas kotlin google developer expert batch 2 2018____




Please keep in mind that dicoding is very anti plagiarism.

You must not copy paste all/part of the code here, because they will easily detect plagiarism with their tool.

What you can do is learn from here and write your own code for the final project.

I am not responsible for any warn and ban from dicoding.com if you ignore my warning.
